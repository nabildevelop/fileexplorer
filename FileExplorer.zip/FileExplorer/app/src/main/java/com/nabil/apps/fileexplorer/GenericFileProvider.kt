package com.nabil.apps.fileexplorer

import androidx.core.content.FileProvider

class GenericFileProvider: FileProvider()