package com.nabil.apps.fileexplorer.view

import android.content.Context
import android.util.AttributeSet
import android.view.View

class CircleView(context: Context, attrs: AttributeSet): View(context, attrs){

}