package com.nabil.apps.fileexplorer

enum class FileTypeName{Image, Video, TXT, PDF, APK, Sound, Unknown,Excel,Word,PowerPoint,Html,archive}